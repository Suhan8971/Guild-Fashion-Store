from django.urls import reverse
from django.utils import timezone
from datetime import timedelta
from rest_framework.test import APITestCase
from rest_framework import status
from django.contrib.auth import get_user_model
from store.models import Category, Product, ProductSize, Order, OrderItem, ReturnPolicyConfig, OrderReturnRequest, OrderReturnRequestItem, InventoryAuditLog
from unittest.mock import patch, MagicMock

User = get_user_model()

class PostOrderRequestsTestCase(APITestCase):
    def setUp(self):
        # Create standard user
        self.customer = User.objects.create_user(username='customer', password='password123', email='customer@test.com', role='customer')
        self.admin = User.objects.create_user(username='admin', password='password123', email='admin@test.com', role='admin')
        
        # Create categories and products
        self.category = Category.objects.create(name='Shirts', slug='shirts', is_womens=False, is_published=True)
        self.product = Product.objects.create(
            name='Summer Cotton Shirt', category=self.category, price=1000.00, actual_price=1200.00, stock=20, sizes='S,M,L'
        )
        self.variant_s = ProductSize.objects.create(product=self.product, size='S', quantity=10, weight=200, length=10, width=10, height=5)
        self.variant_m = ProductSize.objects.create(product=self.product, size='M', quantity=10, weight=200, length=10, width=10, height=5)

        # Create Order
        self.order = Order.objects.create(
            user=self.customer, status='delivered', total_price=1000.00, shipping_cost=0.00,
            shipping_name='Test Name', shipping_address='Test Address', shipping_city='Test City',
            shipping_pincode='574150', shipping_phone='9999999999', delivered_at=timezone.now() - timedelta(days=2)
        )
        self.order_item = OrderItem.objects.create(order=self.order, product=self.product, quantity=2, price=1000.00, size='S')

        # Create Global Policy
        self.policy = ReturnPolicyConfig.objects.create(
            return_window_days=10, exchange_window_days=10,
            reasons=["Size Issue", "Damaged Product", "Other"]
        )

    def test_eligible_items_api(self):
        self.client.force_authenticate(user=self.customer)
        url = reverse('order-eligible-items', args=[self.order.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_ERROR if response.status_code != 200 else 200)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        data = response.json()
        self.assertEqual(data['order_id'], self.order.id)
        self.assertEqual(len(data['items']), 1)
        
        item = data['items'][0]
        self.assertEqual(item['product_name'], self.product.name)
        self.assertEqual(item['purchased_quantity'], 2)
        self.assertEqual(item['remaining_quantity'], 2)
        self.assertTrue(item['is_returnable'])
        self.assertTrue(item['is_exchangeable'])

    def test_eligible_items_expired_window(self):
        # Expiry test by setting delivered_at far back
        self.order.delivered_at = timezone.now() - timedelta(days=15)
        self.order.save()
        
        self.client.force_authenticate(user=self.customer)
        url = reverse('order-eligible-items', args=[self.order.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        data = response.json()
        item = data['items'][0]
        self.assertFalse(item['is_returnable'])
        self.assertFalse(item['is_exchangeable'])

    def test_create_post_order_request(self):
        self.client.force_authenticate(user=self.customer)
        url = reverse('post-order-requests-list')
        
        payload = {
            'order': self.order.id,
            'items': '[{"order_item_id": ' + str(self.order_item.id) + ', "quantity": 1, "request_type": "exchange", "reason": "Size Issue", "exchange_size": "M"}]'
        }
        response = self.client.post(url, payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        
        req = OrderReturnRequest.objects.get(order=self.order)
        self.assertEqual(req.status, 'requested')
        self.assertEqual(req.items.count(), 1)
        
        item = req.items.first()
        self.assertEqual(item.request_type, 'exchange')
        self.assertEqual(item.exchange_size, 'M')
        self.assertEqual(item.quantity, 1)

    def test_create_post_order_request_validation_qty(self):
        self.client.force_authenticate(user=self.customer)
        url = reverse('post-order-requests-list')
        
        # Quantity exceeds order item quantity
        payload = {
            'order': self.order.id,
            'items': '[{"order_item_id": ' + str(self.order_item.id) + ', "quantity": 3, "request_type": "return", "reason": "Other"}]'
        }
        response = self.client.post(url, payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('exceeds eligible remaining quantity', response.json()['error'])

    @patch('store.shiprocket_service.requests.post')
    def test_admin_approve_and_schedule_shiprocket(self, mock_post):
        # Setup mock returns
        mock_response = MagicMock()
        mock_response.status_code = 200
        # Shiprocket login, create return order, assign awb, schedule pickup responses
        mock_response.json.side_effect = [
            {"token": "mock_token"}, # Login response
            {"shipment_id": 98765, "order_id": 55443}, # Create order response
            {"status": "success", "response": {"data": {"awb_code": "AWB998877", "courier_name": "Delhivery Reverse"}}}, # Assign AWB response
            {"status": "success", "response": {"message": "Pickup scheduled successfully"}} # Schedule pickup response
        ]
        mock_post.return_value = mock_response

        # Create request first
        req = OrderReturnRequest.objects.create(order=self.order, user=self.customer, status='requested')
        OrderReturnRequestItem.objects.create(request=req, order_item=self.order_item, quantity=1, request_type='return', reason='Other')

        self.client.force_authenticate(user=self.admin)
        url = reverse('post-order-requests-approve', args=[req.id])
        response = self.client.post(url, {})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        req.refresh_from_db()
        self.assertEqual(req.status, 'pickup_scheduled')
        self.assertEqual(req.awb_code, 'AWB998877')
        self.assertEqual(req.courier_name, 'Delhivery Reverse')

    def test_process_refund_updates_inventory(self):
        # Create request & items
        req = OrderReturnRequest.objects.create(order=self.order, user=self.customer, status='picked_up')
        OrderReturnRequestItem.objects.create(request=req, order_item=self.order_item, quantity=1, request_type='return', reason='Other')

        # Stock before
        self.assertEqual(self.variant_s.quantity, 10)
        self.assertEqual(self.product.stock, 20)

        self.client.force_authenticate(user=self.admin)
        url = reverse('post-order-requests-process-refund', args=[req.id])
        response = self.client.post(url, {})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Stock after refund should increase by 1
        self.variant_s.refresh_from_db()
        self.product.refresh_from_db()
        self.assertEqual(self.variant_s.quantity, 11)
        self.assertEqual(self.product.stock, 21)

        # Audit log verification
        audit = InventoryAuditLog.objects.filter(action='manual_adjust', product=self.product).first()
        self.assertIsNotNone(audit)
        self.assertEqual(audit.quantity, 1)

    def test_ship_replacement_updates_inventory(self):
        # Create request & items
        req = OrderReturnRequest.objects.create(order=self.order, user=self.customer, status='picked_up')
        OrderReturnRequestItem.objects.create(request=req, order_item=self.order_item, quantity=1, request_type='exchange', reason='Size Issue', exchange_size='M')

        # Stock before (Exchange Size M starts at 10)
        self.assertEqual(self.variant_m.quantity, 10)
        self.assertEqual(self.product.stock, 20)

        self.client.force_authenticate(user=self.admin)
        url = reverse('post-order-requests-ship-replacement', args=[req.id])
        response = self.client.post(url, {})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Stock after shipment of replacement (size M) should decrease by 1
        self.variant_m.refresh_from_db()
        self.product.refresh_from_db()
        self.assertEqual(self.variant_m.quantity, 9)
        self.assertEqual(self.product.stock, 19)

        # Audit log verification
        audit = InventoryAuditLog.objects.filter(action='manual_adjust', product=self.product).first()
        self.assertIsNotNone(audit)
        self.assertEqual(audit.quantity, -1)
